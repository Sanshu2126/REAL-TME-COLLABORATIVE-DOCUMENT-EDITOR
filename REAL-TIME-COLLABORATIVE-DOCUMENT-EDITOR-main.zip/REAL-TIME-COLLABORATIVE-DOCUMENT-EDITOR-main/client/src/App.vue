<template>
  <Editor />
</template>

<script setup>
import Editor from "./components/Editor.vue";
</script>
